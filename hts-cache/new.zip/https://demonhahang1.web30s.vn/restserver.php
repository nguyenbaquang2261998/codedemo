<!DOCTYPE HTML>
<html>
<head>

<link rel="canonical" href="https://demonhahang1.web30s.vn/restserver.php" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=3.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta http-equiv="refresh" content="5400"/>
<meta name="SKYPE_TOOLBAR" content="SKYPE_TOOLBAR_PARSER_COMPATIBLE"/>
<meta http-equiv="Pragma" content="no-cache"/>
<meta http-equiv="Expires" content="-1"/>
<meta http-equiv="Cache-Control" content="no-cache"/>
<meta property=fb:app_id content="164566120964750">
<meta name="format-detection" content="telephone=no" />
<meta name="keywords" content="Nhà hàng Courmet"/>
<meta name="description" content="Nhà hàng Courmet"/>
<meta name="robots" content="index, follow"/>
<meta name="googlebot" content="index, follow">
<meta name="revisit-after" content="1 days"/>
<meta name="generator" content="Nhà hàng Courmet"/>
<meta name="rating" content="General">
<meta property="og:url" content="https://demonhahang1.web30s.vn/">
<meta property="og:description" content="Nhà hàng Courmet">
<meta property="og:title" content="Nhà hàng Courmet">
<meta property="og:image" content="https://demonhahang1.web30s.vn/datafiles/4290/upload/images/14774645692679_logo.png">
<meta property="og:site_name" content="demonhahang1.web30s.vn">
<meta property="og:type" content="product"/>
<meta property="og:locale" content="vi_VN"/>
<meta itemprop="image" content="https://demonhahang1.web30s.vn/datafiles/4290/upload/images/14774645692679_logo.png">
<meta property="article:section" content="Nhà hàng Courmet"/>
<meta property="article:tag" content="Nhà hàng Courmet"/>
<meta property="article:author" content="demonhahang1.web30s.vn"/>
<meta name="twitter:card" content="summary"/>
<meta name="twitter:site" content="@demonhahang1.web30s.vn"/>
<meta name="twitter:title" content="Nhà hàng Courmet"/>
<meta name="twitter:description" content="Nhà hàng Courmet"/>
<meta name="twitter:image" content="https://demonhahang1.web30s.vn/datafiles/4290/upload/images/14774645692679_logo.png"/>
<meta name="twitter:url" content="https://demonhahang1.web30s.vn/"/>
<title>Nhà hàng Courmet</title>
<link rel="shortcut icon" type="image/x-icon" href="https://demonhahang1.web30s.vn/datafiles/4290/upload/images/14774645692679_logo.png"/>
    <script src="https://cdn.web30s.vn/js/jquery-1.8.2.min.js"></script>
    <link href="https://cdn.web30s.vn/css/jquery.mCustomScrollbar.css" rel="stylesheet" type="text/css">
    <link href="https://demonhahang1.web30s.vn/css/global.css?v=6.8.1" rel="stylesheet" type="text/css">
    <link href="https://cdn.web30s.vn/css/divbox.css" rel="stylesheet" type="text/css">
    <link href="https://cdn.web30s.vn/css/bxslider.css" rel="stylesheet" type="text/css">

<script src="https://cdn.web30s.vn/js/divbox.js"></script>
<script src="https://demonhahang1.web30s.vn/js/me.php"></script>
<script src='https://cdn.web30s.vn/js/jquery.easing.1.3.js'></script>
<script src="https://cdn.web30s.vn/js/swfobject.js"></script>
<script src="https://cdn.web30s.vn/js/jquery.bxslider.min.js"></script>
<script src="https://cdn.web30s.vn/js/md5.js"></script>
<script src="https://cdn.web30s.vn/js/jquery.mCustomScrollbar.concat.min.js"></script>
<link href="https://cdn.web30s.vn/css/font-awesome-4.6.3/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="https://demonhahang1.web30s.vn/templates/300-up-86/css/customize.php" rel="stylesheet" type="text/css">



<script>var _active_lang='vn';var fullpath='https://demonhahang1.web30s.vn';var cdn_path='https://cdn.web30s.vn';var baivietid='4290';</script>
<!-- //background css -->
<!-- end backgorund css -->
<script src="/templates/300-up-86/js/jquery.carouFredSel-6.1.0-packed.js"></script>
<script src="/templates/300-up-86/js/tms-0.4.1.js"></script>
<script>
      $(window).load(function(){
      $('.slider')._TMS({
              show:0,
              pauseOnHover:false,
              prevBu:'.prev',
              nextBu:'.next',
              playBu:false,
              duration:800,
              preset:'fade', 
              pagination:true,
              pagNums:false,
              slideshow:8000,
              numStatus:false,
              banners:false,
          waitBannerAnimation:false,
        progressBar:false
      })  
      });
     $(window).load (
      function(){
        var with_scren = $( document ).width();
        if(with_scren < 992) var width_list = 355;
        else var width_list = 255;
        $('.carousel1').carouFredSel({auto: true,prev: '.prev',next: '.next', width: 1020, items: {
            visible : {
              min: 1,
              max: 4
            },
            height: 'auto',
            width: width_list,

        }, responsive: true, 
        
        scroll: 1, 
        mousewheel: false,
        swipe: {onMouse: false, onTouch: false}});

    });      
</script>
<link rel='stylesheet' id='gfont-style-css'  href='https://fonts.googleapis.com/css?family=Roboto%3A100%2C300%2C300italic%2C400%2C400italic%2C500%2C700%2C900%7CRoboto+Slab%3A300%2C400%2C700%7CArapey%3A400%2C400italic%7CLobster%7CCinzel%7CPoiret+One%3A400%7CJosefin+Sans%3A400%7CDomine%3A400&#038;ver=4.4.5' type='text/css' media='all' />
</head>
<body class="cbp-spmenu-push">
		
	<div class="head_top header_admin">
		<div class="bg_top"><script>
	function jsupdate(k,idclass,jscolor) {
	    if(k==0) 		$("."+idclass).css("background-color","#"+jscolor);
	    else if (k==1)	$("."+idclass).css("color","#"+jscolor);
	}
</script>
</div>
	</div>
			
	<div class="height_xanh">&nbsp;</div>
 <header> 
  <div class="zerogrid">
    <div class="col-full">
      <div class="wrap-col">
        <h2><a href="https://demonhahang1.web30s.vn"><img alt='Nhà hàng Courmet' class='img_logo' src='https://cdn.web30s.vn/datafiles/4290/upload/images/14774645692679_logo.png'></a> </h2>
        <div class="menu_block menu_desktop">
          <nav>
            <ul class="sf-menu">
              



<li class=''><a class='' href='https://demonhahang1.web30s.vn'><span>TRANG CHỦ</span></a></li><li class=''><a class='' href='https://demonhahang1.web30s.vn/Gioi-thieu-339804' ><span>Giới thiệu</span></a></li><li class=' '><a class='' href='https://demonhahang1.web30s.vn/Thuc-don' ><span>Thực đơn</span></a><ul class="dl-submenu  " ><li><a href='https://demonhahang1.web30s.vn/Khai-vi-339781'>» Khai vị</a></li><li><a href='https://demonhahang1.web30s.vn/Alacarte-339782'>» Alacarte</a></li><li><a href='https://demonhahang1.web30s.vn/The-gioi-lau-339784'>» Thế giới lẩu</a></li><li><a href='http://demonhahang1.web30s.vn/tiec-cocktail'>» Tiệc Cocktail</a></li></ul></li><li class=''><a  class='' href='https://demonhahang1.web30s.vn/Tin-tuc' ><span>Tin tức</span></a></li><li class=''><a class='' href='https://demonhahang1.web30s.vn/thu-vien-anh' ><span>Thư viện ảnh</span></a></li><li class=''><a class='' href='https://demonhahang1.web30s.vn/video' ><span>Thư viện video</span></a></li><li class=''><a class='' href='https://demonhahang1.web30s.vn/Tuyen-dung-339808' ><span>Tuyển dụng</span></a></li><li class=''><a class='' href='https://demonhahang1.web30s.vn/Lien-he-339806' ><span>Liên hệ</span></a></li>            </ul>
          </nav>
          <div class="clear"></div>
        </div>
        <!--  -->
        <script src="/templates/300-up-86/menu_mb/modernizr.custom.js"></script>
            <script src="/templates/300-up-86/menu_mb/jquery.dlmenu.js"></script>
            <script>
              $(function() {
                $( '#dl-menu' ).dlmenu();
              });

              $(document).ready(function(){
                $('body').click(function(e) {
                      $('#dl-menu').dlmenu('closeMenu'); 
                });
              });
            </script>
            <div class="dv-mnmb">
                <div id="dl-menu" class="dl-menuwrapper">
                  <button class="dl-trigger cur "></button><span class=" cur dl-trigger title_menu"></span>
                  <div class="clear"></div>

                  <ul class="dl-menu">
                    <li class=''><a class='' href='https://demonhahang1.web30s.vn'><span>TRANG CHỦ</span></a></li><li class=''><a class='' href='https://demonhahang1.web30s.vn/Gioi-thieu-339804' ><span>Giới thiệu</span></a></li><li class=' '><a class='' href='https://demonhahang1.web30s.vn/Thuc-don' ><span>Thực đơn</span></a><ul class="dl-submenu  " ><li><a href='https://demonhahang1.web30s.vn/Khai-vi-339781'>» Khai vị</a></li><li><a href='https://demonhahang1.web30s.vn/Alacarte-339782'>» Alacarte</a></li><li><a href='https://demonhahang1.web30s.vn/The-gioi-lau-339784'>» Thế giới lẩu</a></li><li><a href='http://demonhahang1.web30s.vn/tiec-cocktail'>» Tiệc Cocktail</a></li></ul></li><li class=''><a  class='' href='https://demonhahang1.web30s.vn/Tin-tuc' ><span>Tin tức</span></a></li><li class=''><a class='' href='https://demonhahang1.web30s.vn/thu-vien-anh' ><span>Thư viện ảnh</span></a></li><li class=''><a class='' href='https://demonhahang1.web30s.vn/video' ><span>Thư viện video</span></a></li><li class=''><a class='' href='https://demonhahang1.web30s.vn/Tuyen-dung-339808' ><span>Tuyển dụng</span></a></li><li class=''><a class='' href='https://demonhahang1.web30s.vn/Lien-he-339806' ><span>Liên hệ</span></a></li>                  </ul>
              </div>
              <div class="clear"></div>
            </div>
          <div class="clear"></div>
      </div>
    </div>
  </div>
</header>
<div class="slider-relative">
  <div class="slider-block">
    <div class="slider">
      <ul class="items">
                <li>
            <a href="http://web30s.vn" target="_blank"><img src="https://cdn.web30s.vn/datafiles/4290/upload/images/14774695931992_0134117980526990_1600x600.jpg" alt="mở rộng 1 - không xài"></a>
        </li>
                <li>
            <a href="http://web30s.vn" target="_blank"><img src="https://cdn.web30s.vn/datafiles/4290/upload/images/14774699555197_l_706792014_banner2_1600x600.jpg" alt="mở rộng 1 - không xài"></a>
        </li>
                <li>
            <a href="http://web30s.vn" target="_blank"><img src="https://cdn.web30s.vn/datafiles/4290/upload/images/14774696314434_phong-vip.jpg" alt="mở rộng 1 - không xài"></a>
        </li>
              </ul>
    </div>
  </div>
</div>	
	<article>
  		<section class="content gallery pad1" style='padding:0'>
      		<div class="midle_main_idclass fix1200_cus1">
				
<div class="content page1 div_main">
  <div class="zerogrid">
        <div class="row">
          <div class="col-3-5 max-767">
              <div class="wrap-col">
                  <h2>Nhà Hàng Courmet</h2>
                  <div class="page1_block col1">
                    <div class="col-1-3"><img src="https://cdn.web30s.vn/datafiles/4290/upload/thumb_images/14774670213947_05f437f620b5c0540d3aa4ab528aa9b0.jpg" alt=""></div>
                    <div class="col-2-3">
                      <div class="extra_wrapper"><div class="info all">
<p>COURMET tự h&agrave;o mang tới cho qu&yacute; kh&aacute;ch h&agrave;ng những m&oacute;n ăn tinh tế, mang đậm chất truyền thống từ ch&iacute;nh những nguy&ecirc;n liệu gần gũi của Việt Nam.</p>
<p>Kh&ocirc;ng gian nh&agrave; h&agrave;ng kết hợp h&agrave;i h&ograve;a giữa thiết kế đồ họa v&agrave; hội họa mang phong c&aacute;ch đặc trưng, COURMET&nbsp;như một kh&ocirc;ng gian thu nhỏ giữa l&ograve;ng th&agrave;nh phố.</p>
<p>Đặc biệt, nh&agrave; h&agrave;ng c&ograve;n c&oacute; 2 ph&ograve;ng ri&ecirc;ng với sức chứa từ 20- 30 kh&aacute;ch, rất th&iacute;ch hợp để tổ chức c&aacute;c sự kiện như tiệc kỉ niệm ng&agrave;y cưới hay mừng sinh nhật, lưu giữ những khoảnh khắc hạnh ph&uacute;c v&agrave; đ&aacute;ng nhớ.</p>
</div></div>
                    </div>
                    <div class="clear"></div>
                  </div>
              </div>
          </div>
          <div class="col-2-5 max-767">
              <div class="wrap-col left_new_index">
                  <h2>Tin tức</h2>
                  <ul class="list">
                    <li><a href='https://demonhahang1.web30s.vn/nghe-thuat-am-thuc-nhat-trong-banh-ngot-wagashi'>Nghệ thuật ẩm thực Nhật trong bánh ngọt wagashi</a></li><li><a href='https://demonhahang1.web30s.vn/sushi-nghe-thuat-am-thuc-dac-sac-nhat-ban'>Sushi nghệ thuật ẩm thực đặc sắc Nhật Bản</a></li><li><a href='https://demonhahang1.web30s.vn/ruou-sake-truyen-thong-cua-nhat-ban'>Rượu Sake truyền thống của Nhật Bản</a></li><li><a href='https://demonhahang1.web30s.vn/tong-quan-ve-am-thuc-nhat-ban-tinh-te-va-hai-hoa'>Tổng quan về ẩm thực Nhật Bản – tinh tế và hài hòa</a></li><li><a href='https://demonhahang1.web30s.vn/10-mon-an-ngon-noi-tieng-o-nhat-ban-nen-an-khi-du-lich'>10 món ăn ngon, nổi tiếng ở Nhật Bản nên ăn khi du lịch</a></li><li><a href='https://demonhahang1.web30s.vn/van-hoa-am-thuc-cua-dat-nuoc-nhat-ban'>Văn hóa ẩm thực của đất nước Nhật Bản</a></li>
                  </ul>
              </div>
          </div>
        </div>
        <div class="col-full">
          <div class="hor_separator"></div>
        </div>
        <div class="row">
          <div class="col-full">
            <div class="wrap-col">
              <div class="car_wrap">
                <h2>Thực đơn</h2>
                <a href="#" class="prev"></a><a href="#" class="next"></a>
                <div class="dv-presli">          
                  <ul class="carousel1">
                    <li>
                      <div class='dv-index-sp div_zoom_nghien'>
                      	<div class='img_inex_td'>
                        	<a href='https://demonhahang1.web30s.vn/Bo-cuon-thit-hun-khoi-va-foma-nuong-339796'><img class='zoom_nghien' src='https://cdn.web30s.vn/datafiles/4290/upload/thumb_images/14774659941984_c4b1f0256b8c8b8455f9e4c51f1af254.jpg' alt='Bò cuộn thịt hun khói và foma nướng'></a>
                        </div>
                        <div class='min-height-id'>
                        	<div class='col1 upp'> <a href='https://demonhahang1.web30s.vn/Bo-cuon-thit-hun-khoi-va-foma-nuong-339796'>Bò cuộn thịt hun khói và foma nướng</a></div>
                        	<div class='nd'>B&ograve; cuộn thịt hun kh&oacute;i v&agrave; foma nướng</div>
                        </div>
                        <div class='price'>144,000 đ</div>
                      </div>
                    </li><li>
                      <div class='dv-index-sp div_zoom_nghien'>
                      	<div class='img_inex_td'>
                        	<a href='https://demonhahang1.web30s.vn/Ngao-hap-kieu-Thai-339795'><img class='zoom_nghien' src='https://cdn.web30s.vn/datafiles/4290/upload/thumb_images/14774658936761_Ngheu-hap-kieu-Phap.jpg' alt='Ngao hấp kiểu Thái'></a>
                        </div>
                        <div class='min-height-id'>
                        	<div class='col1 upp'> <a href='https://demonhahang1.web30s.vn/Ngao-hap-kieu-Thai-339795'>Ngao hấp kiểu Thái</a></div>
                        	<div class='nd'>Ngao hấp kiểu Th&aacute;i m&oacute;n ngon mỗi ng&agrave;y tại Nh&agrave; h&agrave;ng Courmet</div>
                        </div>
                        <div class='price'>65,000 đ</div>
                      </div>
                    </li><li>
                      <div class='dv-index-sp div_zoom_nghien'>
                      	<div class='img_inex_td'>
                        	<a href='https://demonhahang1.web30s.vn/Ga-nuong-mat-ong-339794'><img class='zoom_nghien' src='https://cdn.web30s.vn/datafiles/4290/upload/thumb_images/14774657997745_cac-quan-ga-han-quoc-dang-lam-mua-lam-gio-o-ha-noi-1.jpg' alt='Gà nướng mật ong'></a>
                        </div>
                        <div class='min-height-id'>
                        	<div class='col1 upp'> <a href='https://demonhahang1.web30s.vn/Ga-nuong-mat-ong-339794'>Gà nướng mật ong</a></div>
                        	<div class='nd'>G&agrave; nướng mật ong m&oacute;n ngon cho mọi b&agrave;n tiệc.</div>
                        </div>
                        <div class='price'>155,000 đ</div>
                      </div>
                    </li><li>
                      <div class='dv-index-sp div_zoom_nghien'>
                      	<div class='img_inex_td'>
                        	<a href='https://demonhahang1.web30s.vn/Tom-su-nuong-moi-339793'><img class='zoom_nghien' src='https://cdn.web30s.vn/datafiles/4290/upload/thumb_images/14774657333668_1.jpg' alt='Tôm sú nướng mọi'></a>
                        </div>
                        <div class='min-height-id'>
                        	<div class='col1 upp'> <a href='https://demonhahang1.web30s.vn/Tom-su-nuong-moi-339793'>Tôm sú nướng mọi</a></div>
                        	<div class='nd'>T&ocirc;m s&uacute; nướng mọi m&oacute;n ăn d&acirc;n d&atilde;, nhưng đầy hương vị Việt.</div>
                        </div>
                        <div class='price'>590,000 đ</div>
                      </div>
                    </li><li>
                      <div class='dv-index-sp div_zoom_nghien'>
                      	<div class='img_inex_td'>
                        	<a href='https://demonhahang1.web30s.vn/Lau-bo-cuon-nam-kim-cham-339792'><img class='zoom_nghien' src='https://cdn.web30s.vn/datafiles/4290/upload/thumb_images/14774656489640_lau-vit-ha-noi.jpg' alt='Lẩu bò cuộn nấm kim châm'></a>
                        </div>
                        <div class='min-height-id'>
                        	<div class='col1 upp'> <a href='https://demonhahang1.web30s.vn/Lau-bo-cuon-nam-kim-cham-339792'>Lẩu bò cuộn nấm kim châm</a></div>
                        	<div class='nd'>Lẩu b&ograve; cuộn nấm kim ch&acirc;m m&oacute;n ngon do những đầu bếp chuy&ecirc;n nghiệp tại nh&agrave; h&agrave;ng Courmet</div>
                        </div>
                        <div class='price'>295,000 đ</div>
                      </div>
                    </li><li>
                      <div class='dv-index-sp div_zoom_nghien'>
                      	<div class='img_inex_td'>
                        	<a href='https://demonhahang1.web30s.vn/Lau-Thai-Hai-San-339791'><img class='zoom_nghien' src='https://cdn.web30s.vn/datafiles/4290/upload/thumb_images/14774655888687_dia-chi-quan-lau-cua-ngon-o-quan-2-lau-cua-akha.jpg' alt='Lẩu Thái Hải Sản'></a>
                        </div>
                        <div class='min-height-id'>
                        	<div class='col1 upp'> <a href='https://demonhahang1.web30s.vn/Lau-Thai-Hai-San-339791'>Lẩu Thái Hải Sản</a></div>
                        	<div class='nd'>Lẩu Th&aacute;i Hải Sản đặc sản Th&aacute;i Lan nay đ&atilde; mạt tại Nh&agrave; H&agrave;ng Courmet</div>
                        </div>
                        <div class='price'>275,000 đ</div>
                      </div>
                    </li><li>
                      <div class='dv-index-sp div_zoom_nghien'>
                      	<div class='img_inex_td'>
                        	<a href='https://demonhahang1.web30s.vn/Lau-Cuu-Mong-Co-339790'><img class='zoom_nghien' src='https://cdn.web30s.vn/datafiles/4290/upload/thumb_images/14774655156541_hoasonquan_su_kien_thien_than_4.jpg' alt='Lẩu Cừu Mông Cổ'></a>
                        </div>
                        <div class='min-height-id'>
                        	<div class='col1 upp'> <a href='https://demonhahang1.web30s.vn/Lau-Cuu-Mong-Co-339790'>Lẩu Cừu Mông Cổ</a></div>
                        	<div class='nd'>Những thớ thịt chắc v&agrave; vị ngọt từ m&oacute;n Lẩu Cừu M&ocirc;ng Cổ</div>
                        </div>
                        <div class='price'>55,000 đ</div>
                      </div>
                    </li>                  </ul>
                </div>
              </div>
            </div>
          </div>
  </div>
  <div class="row">
    <div class="bottom_block">
      <div class="col-1-2">
        <h3>Mạng xã hội</h3>
        <div class="socials">
          <a href="https://www.facebook.com/www.pavietnam.net" target='_blank'></a>
          <a href="https://twitter.com/wwwpavietnamcom" target='_blank'></a>
          <a href="https://www.youtube.com/channel/UC2CD0jJ4HZLCZReyCyzwp0g" target='_blank'></a>
        </div>
        <nav>
          <ul>
            <li>
              <a href="https://demonhahang1.web30s.vn">trang chủ</a>
            </li>
            <li>
                <a href='https://demonhahang1.web30s.vn/Gioi-thieu-339804'>Giới thiệu</a>            </li>
            <li >
                <a href="/Thuc-don">thực đơn</a>
            </li>
            <li>
              <a  href="/Tin-tuc">tin tức</a>
            </li>
                                         
                        <li class='dichvu_class' >
                <a href='/Dich-vu-339805'>Dịch vụ</a>            </li>
                                        <li class='tuyendung_class'>
                    <a href='/Tuyen-dung-339808'>Tuyển dụng</a>                </li>
                        <li><a href="https://demonhahang1.web30s.vn/contact/">liên hệ</a></li>
          </ul>
        </nav>
      </div>
      <div class="col-1-2">
        <h3>Đăng ký nhận tin</h3>
        <p class="col1">Hãy đăng ký nhận bản tin để nhận được những khuyến mãi hấp dẫn nhất từ chúng tôi!</p>
        <form id="newsletter">
                  <div class="success">Đăng ký nhận tin</div>
                  <label class="email">
                       <input type="text" name="newsletter" id="newsletter_id" value="Nhập địa chỉ email của bạn..." onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Nhập địa chỉ email của bạn...';}">
                       <a href="#" class="btn" onclick="return NewsLetter();">Đăng ký</a> 
                  </label> 
              </form> 
          </div>
      </div>
    </div>
    </div>
  </div>
</div>			</div>
		</section>
	</article>

	<div class="clear"></div>
<footer>
    <div class="zerogrid">
        <div class="col-full">
            <div class="wrap-col">
                <div class="dv-foot">
                    <p><strong>NH&Agrave; H&Agrave;NG TIỆC CƯỚI COURMET RESTAURANT</strong></p>
<p>Địa chỉ 1: 118 Phan Bội Ch&acirc;u, Ho&agrave;n Kiếm, H&agrave; Nội - Điện thoại:(04)3253 3622 - Fax:(04) 39325223 &ndash; Hotline: 0935 222 333<br />Địa chỉ 2: Tầng 1, 21T2 Ho&agrave;ng Đạo Th&uacute;y, Cầu Giấy, H&agrave; Nội - Điện thoại:(04)20123633 - Fax:(04)0021252 &ndash; Hotline: 090 218 3322<br />Địa chỉ 3: 340 Phan Đ&igrave;nh Ph&ugrave;ng, Ba Đ&igrave;nh, H&agrave; Nội - Điện thoại:(04)0203 0032 - Fax: (04)2135 0111 &ndash; Hotline: 0921 346 443<br />Đặt Tiệc, Kh&aacute;ch Đo&agrave;n, Kh&aacute;ch Du Lịch: 0904 445 455 - (04)2536 3633 - Email: sales@courmet.vn</p>                </div>
                                <div class="coppy_right">
                    <p><span class="footer_copyright"><a href="https://demonhahang1.web30s.vn"  class="a_copyright">Copyright © </a></span></p>
                </div>

            </div>
        </div>
    </div>
</footer>
<style type="text/css">#back-top{position: fixed;bottom: 55px;right: 25px;z-index: 9999}#back-top a{width: 32px;display: block;text-align: center;font: 11px/100% Arial,Helvetica,sans-serif;text-transform: uppercase;text-decoration: none;color: #444c4e;-webkit-transition: 1s;-moz-transition: 1s;transition: 1s}#back-top a:hover{color: #000}#back-top span{width: 32px;height: 32px;display: block;margin-bottom: 5px;background-size: 15px 15px;-webkit-border-radius: 5px;-moz-border-radius: 5px;border-radius: 5px;-webkit-transition: 1s;-moz-transition: 1s;transition: 1s;opacity: 0.9}#back-top a:hover span{}</style><p id="back-top" style="display: block;"><a href="#top"><span><img src="/templates/300-up-86/images/move-top.png"></span></a></p><script type="text/javascript">$(document).ready(function(){  $("#back-top").hide(); $(function () { $(window).scroll(function () { if ($(this).scrollTop() > 100) { $('#back-top').fadeIn(); } else { $('#back-top').fadeOut(); } }); $('#back-top a').click(function () { $('body,html').animate({ scrollTop: 0 }, 800); return false; }); });});</script>
<script>
    if ($('a.lightbox').length > 0) {
        $('a.lightbox').divbox();
    }
</script>
<div id="fb-root"></div>
<script>
    window.fbAsyncInit = function () {
        FB.init({
            xfbml: true,
            version: 'v4.0',
            appId: 164566120964750,
            autoLogAppEvents: true
        });
    };

    (function (d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s);
        js.id = id;
        js.src = 'https://connect.facebook.net/vi_VN/sdk/xfbml.customerchat.js';
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));
</script>

 </body>
</html>